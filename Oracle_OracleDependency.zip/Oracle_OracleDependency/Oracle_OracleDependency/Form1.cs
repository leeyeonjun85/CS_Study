using Oracle.ManagedDataAccess.Client;
using Oracle_OracleDependency.Models;
using System.Data;
using System.Drawing;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Oracle_OracleDependency
{
    public partial class Form1 : Form
    {
        string constr = "User Id=testuser1;Password=0330;Data Source=localhost:1521/XEPDB1;";
        OracleConnection? con;
        OracleDependency? dep;
        OracleCommand? cmd;
        OracleDataAdapter adapter;
        DataTable dataTable;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Create the connection
            con = new OracleConnection(constr);
            cmd = new OracleCommand("SELECT * FROM \"school\"", con);
            con.Open();

            // Set the port number for the listener to listen for the notification
            // request
            OracleDependency.Port = 1005;

            // Create the adapter
            adapter = new OracleDataAdapter("SELECT * FROM \"school\"", con);

            // Create an OracleDependency instance and bind it to an OracleCommand
            // instance.
            // When an OracleDependency instance is bound to an OracleCommand
            // instance, an OracleNotificationRequest is created and is set in the
            // OracleCommand's Notification property. This indicates subsequent 
            // execution of command will register the notification.
            // By default, the notification request is using the Database Change
            // Notification.
            dep = new OracleDependency(cmd);

            // Create the DataTable
            dataTable = new DataTable();

            // Fill the DataTable with initial data
            adapter.Fill(dataTable);

            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dataTable;

            // The notification registration is created and the query result sets 
            // associated with the command can be invalidated when there is a 
            // change.  When the first notification registration occurs, the 
            // notification listener is started and the listener port number 
            // will be 1005.
            cmd.ExecuteNonQuery();
            con.Close();

            cmd.Notification.IsNotifiedOnce = false;

            // Change Event
            dep.OnChange += new OnChangeEventHandler(Dependency_OnChange);
        }

        private void Dependency_OnChange(object sender, OracleNotificationEventArgs args)
        {
            textBox1.BeginInvoke(() => textBox1.Text += Environment.NewLine + "�̺�Ʈ�� ���Խ��ϴ�.");

            if (args.Source == OracleNotificationSource.Data)
                switch (args.Info)
                {
                    case OracleNotificationInfo.Insert:
                        textBox1.BeginInvoke(()=>textBox1.Text += Environment.NewLine + "���� �Դϴ�.");
                        dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.BeginInvoke(() => dataGridView1.DataSource = dataTable);
                        break;
                    case OracleNotificationInfo.Delete:
                        textBox1.BeginInvoke(() => textBox1.Text += Environment.NewLine + "���� �Դϴ�.");
                        dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.BeginInvoke(() => dataGridView1.DataSource = dataTable);
                        break;
                    case OracleNotificationInfo.Update:
                        textBox1.BeginInvoke(() => textBox1.Text += Environment.NewLine + "���� �Դϴ�.");
                        dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.BeginInvoke(() => dataGridView1.DataSource = dataTable);
                        break;
                }
        }
    }
}
